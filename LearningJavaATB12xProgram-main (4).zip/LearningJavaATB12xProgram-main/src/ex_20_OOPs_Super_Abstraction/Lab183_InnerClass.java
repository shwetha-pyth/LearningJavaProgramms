package ex_20_OOPs_Super_Abstraction;

public class Lab183_InnerClass {

}
class A{
    class B{
        class C{

        }
    }
}

//public class ABC{
//
//}