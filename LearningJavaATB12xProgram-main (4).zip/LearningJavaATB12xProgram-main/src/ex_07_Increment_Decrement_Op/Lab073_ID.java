package ex_07_Increment_Decrement_Op;

public class Lab073_ID {
    public static void main(String[] args) {

        int a = 10;
        int result = a++;
        System.out.println(a);
        System.out.println(result);
    }
}
