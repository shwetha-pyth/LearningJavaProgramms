package ex_07_Increment_Decrement_Op;

public class Lab078_De_P2 {
    public static void main(String[] args) {
        int a= 10;
        int result = --a; // 9
        System.out.println(result);
        System.out.println(a); // 9
    }
}
