package ex_03_Literals;

public class Lab029_Literals_P1 {
    public static void main(String[] args) {
        int age = 65;
        // Literal - Integral

        final float pi = 3.14f;
        //  Literal - float


        final int girl_age = 18;
        //girl_age = 19;

    }
}
