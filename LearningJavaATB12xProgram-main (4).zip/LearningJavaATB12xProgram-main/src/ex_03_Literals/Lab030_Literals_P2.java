package ex_03_Literals;

public class Lab030_Literals_P2 {
    public static void main(String[] args) {
        float pi = 3.14f;
        float pi2 = 3.14F;
        float x = 10.00f;
    }
}
