package ex_26_Collection_Framework.List;

public class Lab226_Array_Problem {
    public static void main(String[] args) {
        Integer[] arr = new Integer[10];
        arr[0] = 1;

        // 1. Fixed Size
        // 2. Same data can  be stored.
        // 3. wastage of memory for the 9 elements
        // 4. insertion and deletion is heavy operation.





    }
}
