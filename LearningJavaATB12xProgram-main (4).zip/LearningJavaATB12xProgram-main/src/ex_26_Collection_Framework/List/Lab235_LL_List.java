package ex_26_Collection_Framework.List;

import java.util.*;

public class Lab235_LL_List {
    public static void main(String[] args) {
//        List mylist  = new ArrayList();
        List mylist  = new LinkedList();
        mylist.add(1);
        mylist.add(2);
        mylist.add(3);
        mylist.add(4);
        mylist.add(4);
        System.out.println(mylist);
    }
}
