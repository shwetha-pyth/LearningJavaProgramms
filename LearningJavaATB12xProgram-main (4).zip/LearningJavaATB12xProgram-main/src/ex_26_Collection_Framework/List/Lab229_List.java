package ex_26_Collection_Framework.List;

import java.util.ArrayList;
import java.util.List;

public class Lab229_List {
    public static void main(String[] args) {
        List mylist = new ArrayList(5);
        List mylist0 = new ArrayList();





    }
}
