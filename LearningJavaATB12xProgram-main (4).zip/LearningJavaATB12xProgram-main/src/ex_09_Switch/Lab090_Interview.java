package ex_09_Switch;

public class Lab090_Interview {
    public static void main(String[] args) {
        boolean b = true;
//        switch (b) {
//        }
    }
}
