package ex_09_Switch;

public class Lab088_INTERVIEW {
    public static void main(String[] args) {
        int a = 10;
        switch (a) {

        }
    }
}
