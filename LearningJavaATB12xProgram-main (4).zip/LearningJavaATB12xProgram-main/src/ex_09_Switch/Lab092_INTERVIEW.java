package ex_09_Switch;

public class Lab092_INTERVIEW {
    public static void main(String[] args) {
        int a = 98;
        switch (a) {
            case 98:
                System.out.println("98");
//            case 98:
//                System.out.println("98");
        }
    }
}
