package ex_17_OOPs;

public class Lab160 {
    public static void main(String[] args) {
        Student s1 = new Student();
        //1. Student - Class Loading
        //2. s1 - Object Ref.
        //3. new Student() -> Object creation
    }
}

class Student{
    String name;
    int roll;

    void sleep(){}


}