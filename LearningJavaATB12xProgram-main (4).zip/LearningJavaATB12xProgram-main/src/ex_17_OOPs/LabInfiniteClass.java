package ex_17_OOPs;

public class LabInfiniteClass {
}

class A{}
class B{}
class C{}