package ex_17_OOPs;

public class LabTask {
    String name;

    LabTask(){
        System.out.println("Default Constructor is called");
    }



    void printName(){
        System.out.println("Hi, name");
    }
}
