package ex_17_OOPs;

public class MainLabTask {
    public static void main(String[] args) {
        Baby b1 = new Baby();
        Baby b2 = null;

    }
}
