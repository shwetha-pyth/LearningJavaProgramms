package ex_17_OOPs;

public class D {
}
