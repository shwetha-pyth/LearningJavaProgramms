package ex_17_OOPs;

public class Baby {
    String name;

    Baby(){
        System.out.println("Hi, Shona");
        name  = "Shona";
    }
    Baby(String n){

    }

}
