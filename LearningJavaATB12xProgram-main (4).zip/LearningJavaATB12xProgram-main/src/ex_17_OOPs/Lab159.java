package ex_17_OOPs;

public class Lab159 {
    public static void main(String[] args) {
        ATBx amit = new ATBx();
        // Class - ATBx
        // Object Ref - amit
        // Object -> new ATBx();

        amit.name = "Amit sharma";
        amit.doAssignment();

        ATBx pramod = new ATBx();
        pramod.name = "Pramod dutta";
        pramod.doAssignment();

        D obRef = new D();
        A a = new A();

    }
}
