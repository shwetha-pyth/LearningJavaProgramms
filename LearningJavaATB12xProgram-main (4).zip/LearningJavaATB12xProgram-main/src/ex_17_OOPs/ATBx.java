package ex_17_OOPs;

public class ATBx {

    // Attributes
    String name;
    int age;
    String gender;
    int salary;
    long phone_no;
    String address;
    String courseName;
    String paymentID;


    // Behaviour
    void speak(){}
    void eat(){}
    void sleep(){};
    void doAssignment(){};
    void watchRecordings(){};

}
