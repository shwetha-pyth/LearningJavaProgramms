package ex_25_Generics;

import java.util.ArrayList;
import java.util.List;

public class Lab_Generics_List {
    public static void main(String[] args) {
        List int0 = new ArrayList<>();
        int0.add(12);
        int0.add(34);
        int0.add(90);
        int0.add("Pramod");

    }
}
