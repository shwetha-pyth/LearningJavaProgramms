package ex_25_Generics;

import java.util.ArrayList;
import java.util.List;

public class Lab_REAL_AUTOMATION {
    public static void main(String[] args) {
        //  WebElement -> , email, password, subBtn
        //
        List list_element = new ArrayList<>();
        list_element.add("email");
        list_element.add(123456);
        list_element.add(true);
    }
}
