package ex_25_Generics;

public class Lab225_Generics {
    public static void main(String[] args) {
        temp(3, 4);
        temp(3.34, 4.45);
        temp("pramod", "dutta");
    }

    static <Pramod> Pramod temp(Pramod a, Pramod b) {

        return null;
    }

    static <T> T temp_sum(T a, T b){
        return null;
    }

}
