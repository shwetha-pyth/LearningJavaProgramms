package ex_11_While;

public class Lab116_While_2 {
    public static void main(String[] args) {
        int modi = 1;
        while (modi <= 15) {
            System.out.println("Modi will do 15 years");
            modi++;
        }
    }
}
