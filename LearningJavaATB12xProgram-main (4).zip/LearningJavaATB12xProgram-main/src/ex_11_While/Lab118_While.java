package ex_11_While;

public class Lab118_While {
    public static void main(String[] args) {
        while (true){
            System.out.println("Hello, Pramod");
        }

    }
}
