package ex_11_While;

public class Lab119_IQ {
    public static void main(String[] args) {
        int i1 = 10;
        while (i1>=1){
            System.out.println(i1);
            i1--;
        }
    }
}
