package ex_13_Functions;

public class Lab128_Functions {
    public static void main(String[] args) {

// Built - in
        // Created by the java Guys.
        int result = Math.min(3,4);
        System.out.println(result);


    }
}
