package ex_13_Functions;

public class Lab129_Method_Functions {
    public static void main(String[] args) {
        // Step 2 - Call
        name_of_the_func();
    }

    //  Step 1 - Def

    static  void name_of_the_func(){
        System.out.println("Hi");
    }
}
