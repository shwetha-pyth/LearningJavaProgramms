package ex_13_Functions;

public class Lab133_InterviewQ {
    public static void main(String[] args) {

    }

    public static void main(String args) {

    }

    public static int main(int args) {
        return 10;
    }

    public static int main(float args) {
        return 10;
    }

    public static boolean main(boolean args) {
    return true;
    }


}
