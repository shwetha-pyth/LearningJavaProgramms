package ex_16_Arrays;

public class Lab158_String_CLI {
    public static void main(String[] args) {
        for (int i = 0; i < args.length ; i++) {
            System.out.println(args[i]);
        }
    }
}
