package ex_23_Wrapper_Class;

public class Lab201_Wrapper {

}

class ATB{
    String name;

    void print(){
        System.out.println("Hi, name");
    }

}