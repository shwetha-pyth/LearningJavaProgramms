package ex_23_Wrapper_Class;

public class Lab203_Wrapper_Class {
}

class ATB1{
    String name;
    Long phone;
    Integer salary;
    Float GST;
    Boolean isMarried;

    //int -> data Type
    // Integer - class - who object can be created.

    // Why Java is not pure OOPs? - Becoz -> primitive data types.

}