package ex_23_Wrapper_Class;

public class Lab202_Wrapper {
    public static void main(String[] args) {
        int a = 10;
        // a. // no , attribute

        // char, short, byte, logn, float, double, - we will avoid them now

        // Character, Short., Byte, Long, Float, Double, Integer

        Integer a1 = 10;
        System.out.println(a1);

        System.out.println(Integer.MAX_VALUE);
        System.out.println(Integer.MIN_VALUE);


    }
}
