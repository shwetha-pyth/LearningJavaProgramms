package ex_24_Object;

public class LabObject {
    public static void main(String[] args) {
        Object a = new Object();
    }
}
