package ex_08_If_Condition;

public class Lab080_If {
    public static void main(String[] args) {


        int age= 17;
        if(age > 18){
            System.out.println("Yes you are allowed to vote!");
        }



    }
}
