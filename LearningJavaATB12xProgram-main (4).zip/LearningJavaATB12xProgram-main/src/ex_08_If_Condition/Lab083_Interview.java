package ex_08_If_Condition;

public class Lab083_Interview {
    public static void main(String[] args) {
        int a = 10;
        if (a == 4) {
            System.out.println("haha");
        } else {
            System.out.println("hoho");
        }
    }
}
