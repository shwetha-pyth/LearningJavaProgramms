package ex_04_Operators;

public class Lab053_Interview {
    public static void main(String[] args) {
        long l = 10l; // 8 Byte, 64 Bits

        String s = "name"; //  8 Byte, 64 Bits
    }
}
