package ex_04_Operators;

public class Lab054_Interview_Char_INT {
    public static void main(String[] args) {
        char a1 = 'A'; // ASCII -> 65
        char b1 = 'B'; // 66
        System.out.println(a1 + b1);
        // a1+b1 - 65+66 -> 131
    }
}
