package ex_04_Operators;

public class Lab045_EqualS {
    public static void main(String[] args) {
        // = ,==
        // == ? ->  Compare the values
        System.out.println( 10 == 10);
        int a = 10;
        System.out.println(a);

    }
}
