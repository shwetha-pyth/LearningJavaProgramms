package ex_04_Operators;

public class Lab056_Interview_Short_Char {
    public static void main(String[] args) {
        short s = 10;
        char c = 'A';//65
        System.out.println(c+s);
    }
}
