package ex_04_Operators;

public class Lab050_New_Operator {
    public static void main(String[] args) {

        //  New operator
        String s1 = new String("pramod");
        // Learn in the OOPs



    }
}
