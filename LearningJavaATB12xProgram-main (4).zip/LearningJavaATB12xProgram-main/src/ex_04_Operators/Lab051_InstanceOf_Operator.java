package ex_04_Operators;

public class Lab051_InstanceOf_Operator {
    public static void main(String[] args) {
        // New Operator
        String s1 = new String("Pramod");
        int a = 10;
        // Learn this in OOPs

        System.out.println(s1 instanceof String);

    }
}
