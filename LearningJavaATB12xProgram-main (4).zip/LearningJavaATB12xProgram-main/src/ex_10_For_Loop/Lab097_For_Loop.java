package ex_10_For_Loop;

public class Lab097_For_Loop {
    public static void main(String[] args) {


        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
        System.out.println(4);
        System.out.println(5);
        System.out.println("..");
        System.out.println(10);



    }
}
