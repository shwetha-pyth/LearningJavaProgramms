package ex_10_For_Loop;

public class Lab098_For_Loop {

    public static void main(String[] args) {
        // For Loop
        // Help you to repeat a block of code.

        // Initialization -> Condition -> Updation(Incre/decre)
        // ICU

        for(int i=0; i< 10;i++){ // Times -> 10, 0 to 9
            System.out.println(i);
        }



    }



}
