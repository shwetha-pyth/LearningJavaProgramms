package ex_10_For_Loop;

public class Lab114_For_Real_Case {
    public static void main(String[] args) {
        // Elements in the page , Future automation
        //n -> number of images, elements, inputs
        //int n = 10;
        for (int i = 0; i <10; i++) {
            System.out.println("print the details of rhe elements");
        }
    }
}
