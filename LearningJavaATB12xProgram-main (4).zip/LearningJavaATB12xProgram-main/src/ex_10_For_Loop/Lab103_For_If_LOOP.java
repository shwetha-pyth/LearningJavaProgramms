package ex_10_For_Loop;

public class Lab103_For_If_LOOP {
    public static void main(String[] args) {
        for(int shruti=0; shruti < 18; shruti++){ // 0 to 17, 18 times
            if (shruti > 15){
                System.out.println("Gift from Papa, IPhone");
            }
            else {
                System.out.println("No Gift");
            }
        }
    }
}
