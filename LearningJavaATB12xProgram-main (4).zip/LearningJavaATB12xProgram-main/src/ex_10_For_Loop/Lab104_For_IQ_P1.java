package ex_10_For_Loop;

public class Lab104_For_IQ_P1 {
    public static void main(String[] args) {
        for (int i = 0;i>10 ;) {
            System.out.println("Hello");
        }
    }
}
