package ex_10_For_Loop;

public class Lab108_ForLoop_3 {
    public static void main(String[] args) {
        for (int i = -1; i > -10 ; i--) {
            System.out.println(i);
        }

        int i = 10;
        for (; i > 0; i--) {
            System.out.println(i);
        }
    }
}
