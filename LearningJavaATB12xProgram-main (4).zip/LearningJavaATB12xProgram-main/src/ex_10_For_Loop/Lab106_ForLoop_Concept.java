package ex_10_For_Loop;

public class Lab106_ForLoop_Concept {
    public static void main(String[] args) {
        // for ( I ; C ; U )
        for(int i=0;i<10;i++){

        }
    }
}
