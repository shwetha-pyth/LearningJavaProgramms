package ex_10_For_Loop;

public class Lab101_For_Loop_IQ {
    public static void main(String[] args) {
        for (int i = 0; i > 1 ; i++) {
            System.out.println(i);
        }
        System.out.println("End");
    }
}
