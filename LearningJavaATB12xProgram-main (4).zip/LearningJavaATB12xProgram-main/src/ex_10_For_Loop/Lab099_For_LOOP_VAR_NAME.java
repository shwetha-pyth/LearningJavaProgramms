package ex_10_For_Loop;

public class Lab099_For_LOOP_VAR_NAME {
    public static void main(String[] args) {
            for (int aditi = 0; aditi < 10; aditi++) {
                System.out.println(aditi);
            }
        }

}
