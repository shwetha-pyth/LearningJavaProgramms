package ex_15_StringBuffer_Builder_StringFunctions;

public class Lab146_SB {
    public static void main(String[] args) {
        StringBuilder stringBuilder = new StringBuilder("Pramod");
        stringBuilder.append(123);
        System.out.println(stringBuilder);
    }
}
