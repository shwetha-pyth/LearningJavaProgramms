package ex_01_Java_Basics;

public class Lab012_Common_Math_Exception {
    public static void main(String[] args) {
        System.out.println(10/0); // java.lang.ArithmeticException: / by zero
    }
}
