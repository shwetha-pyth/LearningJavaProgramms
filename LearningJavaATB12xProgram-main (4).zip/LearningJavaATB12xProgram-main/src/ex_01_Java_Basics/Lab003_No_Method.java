package ex_01_Java_Basics;

public class Lab003_No_Method {
}
