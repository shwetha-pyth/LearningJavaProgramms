package ex_01_Java_Basics;

public class This_is_a_very_long_name_class_blah_blah {
}
