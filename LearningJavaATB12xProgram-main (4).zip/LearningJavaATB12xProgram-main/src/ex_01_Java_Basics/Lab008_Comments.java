package ex_01_Java_Basics;

public class Lab008_Comments {

    /**
     * Author - Pramod
     * Course :  ATB11x
     * This is a documentation comment
     * @param args command-line arguments
     * @return void
     */
    public static void main(String[] args) {
        // Method implementation

//        System.out.println("1");
//        System.out.println("2");
        System.out.println();
    }


}
