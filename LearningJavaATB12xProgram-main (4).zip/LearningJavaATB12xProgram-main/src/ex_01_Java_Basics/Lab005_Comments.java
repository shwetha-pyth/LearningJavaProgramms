package ex_01_Java_Basics;

public class Lab005_Comments {
    public static void main(String[] args) {
        // This is also a comment
        // This is also a comment
        // This is also a comment
        // This is also a comment
        // This is also a comment
        // This is also a comment
        // This is also a comment
        // This is also a comment
        System.out.println("Hell World!");
    }
}
