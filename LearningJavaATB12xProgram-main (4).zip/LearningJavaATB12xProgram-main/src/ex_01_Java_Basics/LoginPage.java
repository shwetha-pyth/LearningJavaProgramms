package ex_01_Java_Basics;

public class LoginPage {
}
