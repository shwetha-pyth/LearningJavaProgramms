package ex_01_Java_Basics;
/**
 * Author : Pramod Dutta
 * Course :  ATB12x
 * Learning :  Java
 *
 **/

public class Lab006_Comments_Multi {
    /**
     * Author : Pramod Dutta
     * Course :  ATB12x
     * Learning :  Java
     *
     **/
    public static void main(String[] args) {
        /**
         * Author : Pramod Dutta
         * Course :  ATB12x
         * Learning :  Java
         *
         **/
        System.out.println("Multi Comment");
    }
}
/**
 * Author : Pramod Dutta
 * Course :  ATB12x
 * Learning :  Java
 *
 **/