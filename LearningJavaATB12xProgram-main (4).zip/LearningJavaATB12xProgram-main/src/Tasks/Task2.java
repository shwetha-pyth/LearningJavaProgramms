package Tasks;

public class Task2 {
    public static void main(String[] args) {
        System.out.println((9 * 3 / 9 + 1) * 3);
    }
}
