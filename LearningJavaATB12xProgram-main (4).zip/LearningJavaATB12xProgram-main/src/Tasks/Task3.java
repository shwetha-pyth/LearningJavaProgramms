package Tasks;

public class Task3 {
    public static void main(String[] args) {
        // Kids -> A -> Excellent, F -> Fail
        // Create a program that will basically be based on
        // the alphabet or based on the grade.
        // You will give the message to the kid if you got
        // excellent, very good, good, needs improvement,
        // fail, or invalid grade.




    }
}
