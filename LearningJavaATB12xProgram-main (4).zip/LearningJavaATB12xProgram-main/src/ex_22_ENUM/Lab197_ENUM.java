package ex_22_ENUM;

public class Lab197_ENUM {
    public static void main(String[] args) {
        System.out.println(Day.SUNDAY);
    }
}

// Constants list
enum Day{
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}