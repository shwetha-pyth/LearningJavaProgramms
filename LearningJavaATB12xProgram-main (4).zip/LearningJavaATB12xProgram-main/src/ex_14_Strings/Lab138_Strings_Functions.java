package ex_14_Strings;

public class Lab138_Strings_Functions {
    public static void main(String[] args) {

        char c = 'A';
        System.out.println(c);

        String s1 = "ABCD";
        System.out.println(s1);
        System.out.println(s1.length());
        System.out.println(s1.toLowerCase());
        System.out.println(s1.toUpperCase());
        System.out.println(s1.concat("E"));




    }
}
