package ex_14_Strings;

public class Lab139_Strings_Interview {
    public static void main(String[] args) {
        String name = "pramod";
        name = name.toUpperCase();
        System.out.println(name);
    }
}
