package ex_14_Strings;

public class Lab136_String_Creation {
    public static void main(String[] args) {
        String s1 = "pramod"; // SCP -> string constant pool

        String s2 = new String("pramod"); // OA - Object area





    }
}
