package ex_14_Strings;

public class Lab135_String_Immutable {
    public static void main(String[] args) {

        String name = "Pramod"; // SCP
        name.toUpperCase();
        System.out.println(name); //PRAMOD x



    }
}
