package ex_14_Strings;

public class LabStringExample2 {
    public static void main(String[] args) {


        CharSequence s = "Pramod".subSequence(1,4);
        System.out.println(s);


    }
}
