package ex_18_OOPs_Constructors;

public class LabInstancevsLocal {
    String name; // instance variable or attribute or data members or properties

    void hello(){
        String name = "Pramod";
    }


}
