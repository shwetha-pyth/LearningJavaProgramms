package ex_18_OOPs_Constructors;

public class LoginPage {
    String name;

    LoginPage(){
        System.out.println("Read the data from excel");
        System.out.println("Read the data from mysql");
        System.out.println("Read the data from json");
        System.out.println("Read the data from text file");
        System.out.println("Open the the Page");
    }
}
