package ex_02_Java_Basics_Part2;

public class Lab021_Boolean {
    public static void main(String[] args) {
        boolean is_pramod_married = true;
        boolean prampd_has_audi= false;
        boolean this_is_a_long_name_that_student_asked_from_us_that_is_it_possible = true;

    }
}
