package ex_02_Java_Basics_Part2;

public class Lab015_Variables {
    public static void main(String[] args) {

        // ```
        // data_type variable_name =  variable_value
        //```

        byte age = 65;
//        short age = 65;
        // byte -> data type - type of container
        //  age ->  variable_name |  identifier
        // = -> Assignment Operator ?  (after some time)
        // 65 -> Variable Value |  Literal








        age = 66;
        System.out.println(age);


    }
}
