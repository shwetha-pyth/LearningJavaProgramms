package ex_02_Java_Basics_Part2;

public class Lab016_Variables {
    public static void main(String[] args) {
        int a = 10;
        a = 65+1;
        System.out.println(a);
    }
}
