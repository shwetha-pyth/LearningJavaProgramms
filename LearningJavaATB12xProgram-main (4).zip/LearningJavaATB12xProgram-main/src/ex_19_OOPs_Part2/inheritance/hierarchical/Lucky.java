package ex_19_OOPs_Part2.inheritance.hierarchical;

public class Lucky extends Father{
    void l2(){
        System.out.println("Lucky");
    }
}
