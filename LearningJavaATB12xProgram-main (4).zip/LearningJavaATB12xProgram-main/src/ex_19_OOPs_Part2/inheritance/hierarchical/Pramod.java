package ex_19_OOPs_Part2.inheritance.hierarchical;

public class Pramod extends Father {
    void h2(){
        System.out.println("h2 - Pramod");
    }
}
