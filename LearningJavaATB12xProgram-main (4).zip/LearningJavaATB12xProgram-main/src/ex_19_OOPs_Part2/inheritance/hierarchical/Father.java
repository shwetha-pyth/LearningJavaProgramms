package ex_19_OOPs_Part2.inheritance.hierarchical;

public class Father {
    void home(){
        System.out.println("3BHK");
    }
}
