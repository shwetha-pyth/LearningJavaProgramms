package ex_19_OOPs_Part2.inheritance.hierarchical;

public class Ruhani extends Father {
    void r1(){
        System.out.println("ruhani");
    }
}
