package ex_19_OOPs_Part2.inheritance.hierarchical;

public class Lab171_Hierarchical {
    public static void main(String[] args) {
        Pramod p1 = new Pramod();
        p1.h2();
        p1.home();

        Lucky l1 = new Lucky();
        l1.l2();
        l1.home();

        Ruhani r1 = new Ruhani();
        r1.r1();
        r1.home();
    }

}
