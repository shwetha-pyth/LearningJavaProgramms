package ex_19_OOPs_Part2.inheritance.multipleheritance;

public class Lab172_HI {
    public static void main(String[] args) {
        Son s1  = new Son();
        // s1.money();
    }
}
