package ex_19_OOPs_Part2.inheritance.multipleheritance;

public class Son //extends Father1,Father2{
{

}
