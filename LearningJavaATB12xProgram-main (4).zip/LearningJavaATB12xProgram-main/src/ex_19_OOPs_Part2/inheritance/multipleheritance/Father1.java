package ex_19_OOPs_Part2.inheritance.multipleheritance;

public class Father1 {
    void money(){
        System.out.println("1 CR");
    }

    void f1(){
        System.out.println("f1 car");
    }
}
