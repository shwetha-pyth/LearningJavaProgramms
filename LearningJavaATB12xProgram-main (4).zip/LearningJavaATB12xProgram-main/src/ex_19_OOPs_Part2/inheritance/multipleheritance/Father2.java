package ex_19_OOPs_Part2.inheritance.multipleheritance;

public class Father2 {
    void money(){
        System.out.println("1.5 CR");
    }

    void m1(){
        System.out.println("m1");
    }
}
