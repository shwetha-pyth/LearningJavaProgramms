package ex_19_OOPs_Part2.inheritance.singleinheritance.realExample;

public class Lab169_SI_REAL_Example {
    public static void main(String[] args) {
        TestCase1 t1 = new TestCase1();
        t1.runningTC1();

        System.out.println(" ----- ");

        TestCase2 t2 = new TestCase2();
        t2.runningTC2();
    }
}
