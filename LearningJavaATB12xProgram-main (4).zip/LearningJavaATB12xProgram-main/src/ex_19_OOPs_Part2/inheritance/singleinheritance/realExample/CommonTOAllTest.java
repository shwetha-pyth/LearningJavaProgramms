package ex_19_OOPs_Part2.inheritance.singleinheritance.realExample;

public class CommonTOAllTest {

    void startBrowser(){
        System.out.println("Starting a Browser!!");
    }

    void closeBrowser() {
        System.out.println("Closing Browser!!");
    }

    void readExcelFile(){
        System.out.println("Reading File");
    }

    void readDataBaseFile(){
        System.out.println("Reading File");
    }

}
