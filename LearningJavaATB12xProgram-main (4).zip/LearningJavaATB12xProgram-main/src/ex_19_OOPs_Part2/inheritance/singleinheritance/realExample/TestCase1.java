package ex_19_OOPs_Part2.inheritance.singleinheritance.realExample;

public class TestCase1 extends CommonTOAllTest {

    void runningTC1(){
        startBrowser();
        System.out.println("Running TC 1");
        closeBrowser();
    }
}
