package ex_19_OOPs_Part2.inheritance.singleinheritance;

public class Father {
    int gold_f = 1000;

    void bhk2() {
        System.out.println("Father 2 BHK!");
    }
}
