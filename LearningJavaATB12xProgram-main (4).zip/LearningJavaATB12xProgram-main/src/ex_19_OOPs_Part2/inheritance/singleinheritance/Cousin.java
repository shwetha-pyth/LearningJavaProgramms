package ex_19_OOPs_Part2.inheritance.singleinheritance;

public class Cousin {

    void bhk31(){
        System.out.println("3+1");
    }
}
