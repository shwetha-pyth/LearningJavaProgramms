package ex_19_OOPs_Part2.inheritance.multilevel;


public class Son extends Father {
    void bhk3(){
        System.out.println("bhk3");
    }
}
