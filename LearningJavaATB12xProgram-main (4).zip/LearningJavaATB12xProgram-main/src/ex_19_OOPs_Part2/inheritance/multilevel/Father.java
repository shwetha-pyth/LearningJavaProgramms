package ex_19_OOPs_Part2.inheritance.multilevel;

public class Father extends GrandFather {


//    void home(){
//        System.out.println("Father Home");
//    }

    void extra() {
        System.out.println("Extra");
    }
}
