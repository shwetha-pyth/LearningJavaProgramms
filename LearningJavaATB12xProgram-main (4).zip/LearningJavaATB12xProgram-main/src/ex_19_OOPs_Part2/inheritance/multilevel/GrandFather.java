package ex_19_OOPs_Part2.inheritance.multilevel;

public class GrandFather {
    void home(){
        System.out.println("1BHK");
    }

    void gf(){
        System.out.println("GF");
    }
}
