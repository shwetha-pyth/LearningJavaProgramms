package ex_19_OOPs_Part2;

public class DoubtExample {

}
class Home{
    public void fridge(){

    }
    private void gold_jwe(){

    }

    void sell_gold(){
        gold_jwe();
    }
}