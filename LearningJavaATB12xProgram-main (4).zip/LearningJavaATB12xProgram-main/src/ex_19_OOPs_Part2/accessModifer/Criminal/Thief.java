package ex_19_OOPs_Part2.accessModifer.Criminal;

import ex_19_OOPs_Part2.accessModifer.police.Cop;

public class Thief {
    public static void main(String[] args) {
        Cop thief = new Cop(10);
//        thief.canIShoot();
//        System.out.println(thief.gun);
    }
}
