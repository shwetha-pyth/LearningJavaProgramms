package ex_19_OOPs_Part2.poly.methodoverriding;

public class Father {
    void home(){
        System.out.println("Father - 2BHK");
    }

    void f1(){
        System.out.println("Father - f1");
    }
}
